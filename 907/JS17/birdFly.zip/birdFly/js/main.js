/*获取元素*/
var gameDiv = document.getElementById("game");
var startBtn = document.getElementById("start");

var menuDiv = document.getElementById("menu");
var headDiv = document.getElementById("head");
var scoreDiv = document.getElementById("score");

var pipes = document.getElementById("pipes");
var bird = document.getElementById("bird");
var endMenuDiv = document.getElementById("endMenu");

var game_music = document.getElementById("gamemusic");
var bullet_music = document.getElementById("bullet");
var gameover_music = document.getElementById("gameover");

/**开始游戏**/
var speed = 0; //当前的速度
var maxSpeed = 5; //最大速度
//计时器
var birdUpTimer;
var birdDownTimer;
//记录分数
var score = 0;
startBtn.onclick = function(eve) {
	//取消冒泡
	eve.cancelBubble = true;
	/*隐藏 菜单 logo*/
	menuDiv.style.display = "none";
	headDiv.style.display = "none";
	/*出现 小鸟 score*/
	bird.style.display = "block";
	scoreDiv.style.display = "block";
	/*播放游戏开始音效*/
	game_music.play();
	/*出现管道*/
	setInterval(showPipes, 3000);
	/*小鸟坠落*/
	birdDownTimer = setInterval(birdDown, 30);
	/*碰壁检测*/
	setInterval(function() {
			var lis = document.getElementsByTagName("li");
			for (var i = 0; i < lis.length; i++) {
				collision(lis[i].firstElementChild);
				collision(lis[i].lastElementChild);
			}
	}, 50);
}
/*碰撞检测*/
function collision(obj) {
	var bird_l = bird.offsetLeft;
	var bird_r = bird_l + bird.offsetWidth;
	var bird_t = bird.offsetTop;
	var bird_b = bird_t + bird.offsetHeight;
	
	var l1 = obj.parentElement.offsetLeft;
	var r1 = l1 + obj.offsetWidth;
	var t1 = obj.offsetTop;
	var b1 = t1 + obj.offsetHeight;
	if(bird_r > l1 && bird_t < b1 && bird_l < r1 && bird_b > t1) {
		//碰壁 游戏结束 
		gameOver();
	}	
}


function showPipes() {
	/*创建管道*/
	var li = document.createElement("li");
	li.id = "pipe";
	li.style.left = pipes.clientWidth + "px";
	pipes.appendChild(li);
	/*上管道*/
	var topDiv = document.createElement("div");
	topDiv.className = "pipe-top";
	//随机管道高度
	var height = Math.floor(Math.random() * (200 - 60 + 1) + 60);
	topDiv.style.height = height + "px";
	li.appendChild(topDiv);
	/*下管道*/
	var bottomDiv = document.createElement("div");
	bottomDiv.className = "pipe-bottom";
	bottomDiv.style.height = 300 - height + "px";
	li.appendChild(bottomDiv);
	//移动
	var x = pipes.clientWidth;
	var timer1 = setInterval(function() {
		x--;
		li.style.left = x + "px";
		if(x == -12) {
			//小鸟已穿过管道 得分过关
			getScore();
		}
		if(x == -62) {
			//移除管道 清除计时器
			clearInterval(timer1);
			pipes.removeChild(li);
		}
	}, 10);
}

gameDiv.onclick = begin;
/*开始飞翔*/
function begin() {
	//播放音效
	bullet_music.play();
	//清除计时器
	clearInterval(birdDownTimer);
	clearInterval(birdUpTimer);
	//重置速度
	speed = 5;
	//小鸟上升
	birdUpTimer = setInterval(birdUp, 30);
	
}
/*小鸟上升*/
function birdUp() {
	bird.src = "img/up_bird.png";
	speed -= 0.6;
	if(speed <= 0) {
		speed = 0; 
		clearInterval(birdUpTimer);
		birdDownTimer = setInterval(birdDown, 30);
	}
	bird.style.top = bird.offsetTop - speed + "px";
	
}

/*小鸟坠落*/
function birdDown() {
	//暂停音效
	bullet_music.pause();
	bird.src = "img/down_bird.png";
	speed += 0.4;
	if(speed >= maxSpeed) {
		speed = maxSpeed;
	}
	bird.style.top = bird.offsetTop + speed + "px";
	//坠落到地面 game over
	if(bird.offsetTop + bird.offsetHeight >= 423) {
		//游戏结束
		gameOver();
	}

}

/*游戏结束*/
function gameOver() {
	//清除计时器
	clearAllTimers();
	//播放游戏结束有效
	gameover_music.play();
	var res = confirm("重新来过！");
	if(res) {
		//重新开始游戏
		location.reload();
	}
}
/*清除所有计时器*/
function clearAllTimers() {
	var endtimer = setInterval(function(){},20);
	for (var i = 1; i <= endtimer; i++) {
				clearInterval(i);
	}
}

/**得分*/
function getScore() {
	score++;
	scoreDiv.innerHTML = "";
	if(score < 10) {
		var img = document.createElement("img");
		img.src = "img/" + score + ".jpg"
		scoreDiv.appendChild(img);
	} else if(score >= 10) {
		var img1 = document.createElement("img");
		img1.src = "img/" + Math.floor(score / 10) + ".jpg";
		scoreDiv.appendChild(img1);

		var img2 = document.createElement("img");
		img2.src = "img/" + score % 10 + ".jpg";
		scoreDiv.appendChild(img2);
	}

}